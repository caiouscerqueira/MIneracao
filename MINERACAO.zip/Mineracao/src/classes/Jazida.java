package classes;
import java.lang.System.Logger;
import java.lang.System.Logger.Level;
import java.util.concurrent.Semaphore;

public class Jazida {
  private int minerioDisponivel;
  private Semaphore semaforo;
  
  public Jazida(int qtdMinerio) {
    this.minerioDisponivel = qtdMinerio;
    this.semaforo = new Semaphore(1, true);
  }
  
  public int minerar(int qtd) {
    int minerioMinerado = 0;
    
    try {
      semaforo.acquire();
      if(this.minerioDisponivel >= qtd) {
        this.minerioDisponivel -= qtd;
        minerioMinerado = qtd;
      }
    } catch (InterruptedException ex) {
      //Logger.getLogger(Jazida.class.getName()).log(Level.ERROR, null, ex);
    	System.out.println("Erro");
    } finally {
      semaforo.release();
    }
    
    return minerioMinerado;
  }

public int getMinerioDisponivel() {
	return minerioDisponivel;
}

public void setMinerioDisponivel(int minerioDisponivel) {
	this.minerioDisponivel = minerioDisponivel;
}

public Semaphore getSemaforo() {
	return semaforo;
}

public void setSemaforo(Semaphore semaforo) {
	this.semaforo = semaforo;
}
}