/**
 * 
 */
/**
 * @author Marle
 *
 */
module Mineracao {
}